// script.js

// Get the navigation links
var navLinks = document.querySelectorAll('.nav-links li a');

// Add click event listener to each navigation link
navLinks.forEach(function(link) {
  link.addEventListener('click', handleNavigation);
});

// Function to handle navigation
function handleNavigation(event) {
  event.preventDefault(); // Prevent default link behavior

  var targetPage = event.target.getAttribute('href'); // Get the target page from the link's href attribute

  // Redirect to the target page
  if (targetPage) {
    window.location.href = targetPage;
  }
}
