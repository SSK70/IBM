import os
import numpy as np
from flask import Flask, request, render_template
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Load the trained model
model = load_model("12,h5", compile=False)

# Home page
@app.route('/')
def home():
    return render_template('predict.html')

# Prediction page
@app.route('/prediction')
def prediction():
    return render_template('upload.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get the file from the post request
        f = request.files['image']
        # Save the file to the ./uploads directory
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)
        
        # Load and preprocess the image
        img = image.load_img(file_path, target_size=(64, 64))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        
        # Make the prediction
        pred = np.argmax(model.predict(x))
        op = ['Fighting', 'Arrest', 'Vandalism', 'Assault', 'Stealing', 'Arson', 'Normalvideos', 'Burglary']
        result = op[pred]
        result = 'The predicted output is {}'.format(str(result))
        print(result)
        return render_template('predict.html', text=result)

if __name__ == '__main__':
    app.run()
